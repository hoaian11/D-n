﻿using ASM_NET4.Datas;
using Microsoft.AspNetCore.Mvc;

namespace ASM_NET4.Controllers
{
    public class CustomerController : Controller
    {
        FuntionS f = new();
        public ActionResult Index()
        {
            if (HttpContext.Session.GetString("Name") != null)
            {
                List<Customer> Customer = db.Customers.ToList();
                return View(Customer);

            }
            ViewBag.ShowCheckCus = "VUI LÒNG ĐĂNG NHẬP!";
            return RedirectToAction("Index", "Login");
        }
        Net4DbContext db = new();
        [HttpPost]
        public IActionResult AddCustomer(Customer model)
        {
            if (ModelState.IsValid)
            {
                var newCustomer = new Customer
                {
                    CustomerId = f.RamdomCustomerID(),
                    CustomerName = model.CustomerName,
                    Email = model.Email,
                    Address= model.Address,
                    Pass = model.Pass,
                };


                db.Customers.Add(newCustomer);
                db.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(model);
        }

        [HttpPost]
        public IActionResult EditCustomer(Customer model)
        {
            if (ModelState.IsValid)
            {

                var CustomerEdit = db.Customers
                                .Where(x => x.CustomerName == model.CustomerName)
                                .FirstOrDefault();
                if (CustomerEdit != null)
                {
                    CustomerEdit.CustomerName = model.CustomerName;
                    CustomerEdit.Email = model.Email;
                    CustomerEdit.Address = model.Address;
                    CustomerEdit.Pass = model.Pass;
                    db.SaveChanges();

                }

                return RedirectToAction("Index");
            }

            return View(model);
        }
        [HttpPost]
        public IActionResult RemoveCustomer(Customer model)
        {
            if (ModelState.IsValid)
            {
                var CustomerRemove = db.Customers.Where(x => x.CustomerName == model.CustomerName)
                                                .FirstOrDefault();
                if (CustomerRemove != null)
                {
                    db.Remove(CustomerRemove);
                    db.SaveChanges();
                }
                return RedirectToAction("Index");
            }

            return View(model);
        }

    }
}
