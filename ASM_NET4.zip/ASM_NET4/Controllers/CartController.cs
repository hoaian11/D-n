﻿using ASM_NET4.Datas; // Thêm directive này

using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;

namespace ASM_NET4.Controllers
{
    public class CartController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public CartController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        Net4DbContext db = new();
        FuntionS f = new();
        public IActionResult Index()
        {
            if(HttpContext.Session.GetString("Name") != null)
            {
                List<Cart> cart = db.Carts.ToList();
                ShowTotal();
                return View(cart);

            }
            ViewBag.ShowCheckCus = "VUI LÒNG ĐĂNG NHẬP!";
            return RedirectToAction("Index","Login");
        }
        [HttpPost]
        public IActionResult AddToCart(int ProductId)
        {
            List<Cart> cart = db.Carts.ToList();
            var checkCart = db.Carts.FirstOrDefault(c => c.ProductId == ProductId);
            if (ModelState.IsValid)
            {
                
                var product = db.Products.FirstOrDefault(p => p.ProductId == ProductId);
                if (checkCart == null)
                {
                    string img = product.Picture;
                    Cart newCart = new Cart()
                    {
                        CartId = f.RandomCartID(),
                        ProductId = ProductId,
                        CustomerId = 1,
                        Quantity = 1,
                        
                    };
                    db.Carts.Add(newCart);
                    db.SaveChanges();
                }
                else
                {
                    checkCart.Quantity++;
                    db.SaveChanges();
                }
           
                _logger.LogInformation("Product.ProductId: {ProductId}",ProductId);
            }
            return RedirectToAction("Index");
        }

        public IActionResult Plus(int cartId)
        {
            var minusCart = db.Carts.FirstOrDefault(x => x.CartId == cartId);
            minusCart.Quantity++;
            db.SaveChanges();
            return RedirectToAction("Index");

        }
        public IActionResult Minus(int cartId)
        {
            var minusCart = db.Carts.FirstOrDefault(x => x.CartId == cartId);
            if (minusCart.Quantity > 1)
            {
                minusCart.Quantity--;
                db.SaveChanges();

            }
            else if (minusCart.Quantity == 1)
            {
                db.Remove(minusCart);
                db.SaveChanges();
            }
            return RedirectToAction("Index");

        }
        public void ShowTotal()
        {
            var productPrice = db.Products.ToList();
            for(int i = 0; i < productPrice.Count; i++)
            {
                ViewData["Price" + i] = productPrice[i].Price;
            }
        }
    }
}
