﻿using ASM_NET4.Datas;
using ASM_NET4.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace ASM_NET4.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
        Net4DbContext db = new();

        public IActionResult Index()
        {
            if (HttpContext.Session.GetString("Name") != null)
            {
                List<Product> products = db.Products.ToList();

                return View(products);
            }
            ViewBag.ShowCheckCus = "VUI LÒNG ĐĂNG NHẬP!";
            return RedirectToAction("Index", "Login");
        }
        public IActionResult Login()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}